#!/usr/bin/env bash
set -e
mkdir -p out
javac -encoding UTF-8 -d out src/placement/*.java
java -cp out placement.Main
