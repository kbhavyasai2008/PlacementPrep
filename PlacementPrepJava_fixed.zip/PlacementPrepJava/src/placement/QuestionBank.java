package placement;
import java.util.*;
public class QuestionBank {
    private static final List<Question> QUESTIONS=Arrays.asList(
        new Question("Aptitude","Percentages","What is 20% of 250?",1,"25","50","75","100"),
        new Question("Aptitude","Percentages","A price rises from 80 to 100. Percentage increase?",2,"10%","20%","25%","30%"),
        new Question("Aptitude","Ratios","Simplify the ratio 18:24.",0,"3:4","4:3","2:3","6:7"),
        new Question("Aptitude","Ratios","If A:B=2:3 and A=10, B=?",2,"12","13","15","20"),
        new Question("Aptitude","Time and Work","A finishes a task in 5 days. Work completed per day?",1,"1/10","1/5","1/4","5"),
        new Question("Aptitude","Time and Work","Two people each finish a job in 6 days. Together they take?",0,"3 days","6 days","9 days","12 days"),
        new Question("Aptitude","Probability","Probability of heads on a fair coin toss?",1,"1/4","1/2","1/3","1"),
        new Question("Aptitude","Probability","Probability of rolling a 6 on a fair die?",3,"1/2","1/3","1/4","1/6"),
        new Question("Technical","Java OOP","Which feature lets one interface have many implementations?",2,"Encapsulation","Compilation","Polymorphism","Serialization"),
        new Question("Technical","Java OOP","Which keyword prevents inheritance of a class?",0,"final","static","abstract","private"),
        new Question("Technical","Java OOP","Which access modifier limits a member to its own class?",1,"public","private","protected","default"),
        new Question("Technical","Java OOP","A constructor in Java has what return type?",3,"void","int","Object","No return type"),
        new Question("Technical","Data Structures","Which data structure follows FIFO?",0,"Queue","Stack","Tree","Heap"),
        new Question("Technical","Data Structures","Which data structure follows LIFO?",1,"Queue","Stack","Graph","HashMap"),
        new Question("Technical","Data Structures","Binary search on a sorted array takes?",2,"O(n)","O(n^2)","O(log n)","O(1)"),
        new Question("Technical","DBMS","Which SQL command retrieves rows?",3,"INSERT","UPDATE","DELETE","SELECT"),
        new Question("Technical","DBMS","What does a primary key enforce?",0,"Unique, non-null identification","Sorted rows","Encrypted columns","Duplicate records"),
        new Question("Technical","DBMS","Which SQL clause filters groups after GROUP BY?",2,"WHERE","ORDER BY","HAVING","LIMIT"),
        new Question("Technical","Networking","What does HTTP stand for?",1,"High Transfer Text Protocol","Hypertext Transfer Protocol","Host Transfer Text Process","Hyperlink Transport Program"),
        new Question("Technical","Networking","Which layer handles IP routing?",0,"Network","Application","Presentation","Physical")
    );
    public static List<String> topics(String category) {
        Set<String> topics=new TreeSet<>();
        for(Question q:QUESTIONS)if(category.equals("Mixed")||q.getCategory().equals(category))topics.add(q.getTopic());
        return new ArrayList<>(topics);
    }
    public static List<Question> select(String category,int count) {
        return select(category,topics(category),count);
    }
    public static List<Question> select(String category,Collection<String> topics,int count) {
        List<Question> matches=new ArrayList<>();
        for(Question q:QUESTIONS)
            if((category.equals("Mixed")||q.getCategory().equals(category))&&topics.contains(q.getTopic()))matches.add(q);
        Collections.shuffle(matches);
        return new ArrayList<>(matches.subList(0,Math.min(count,matches.size())));
    }
    public static int count(String category){
        return count(category,topics(category));
    }
    public static int count(String category,Collection<String> topics){
        int n=0;for(Question q:QUESTIONS)
            if((category.equals("Mixed")||q.getCategory().equals(category))&&topics.contains(q.getTopic()))n++;
        return n;
    }
}
