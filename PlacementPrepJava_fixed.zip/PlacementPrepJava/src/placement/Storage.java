package placement;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class Storage {
    private final Path directory=Paths.get(System.getProperty("user.home"),".placement-prep-java");
    private final Path users=directory.resolve("users.dat");
    public Storage(){try{Files.createDirectories(directory);}catch(IOException e){throw new IllegalStateException(e);}}
    @SuppressWarnings("unchecked")
    private <T> T read(Path path,T fallback){
        if(!Files.exists(path))return fallback;
        try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(path))){return (T)in.readObject();}
        catch(Exception e){throw new IllegalStateException("Cannot read saved data: "+path,e);}
    }
    private void write(Path path,Object data){
        try(ObjectOutputStream out=new ObjectOutputStream(Files.newOutputStream(path))){out.writeObject(data);}
        catch(IOException e){throw new IllegalStateException("Cannot save data: "+path,e);}
    }
    public synchronized User findUser(String username){
        Map<String,User> all=read(users,new HashMap<String,User>());
        return all.get(username.toLowerCase(Locale.ROOT));
    }
    public synchronized boolean register(User user){
        Map<String,User> all=read(users,new HashMap<String,User>());
        if(all.containsKey(user.getUsername()))return false;
        all.put(user.getUsername(),user);write(users,all);return true;
    }
    private Path resultsPath(String username){return directory.resolve("results_"+username+".dat");}
    public synchronized List<TestResult> getResults(String username){
        return read(resultsPath(username),new ArrayList<TestResult>());
    }
    public synchronized void saveResult(String username,TestResult result){
        List<TestResult> all=getResults(username);all.add(result);write(resultsPath(username),all);
    }
}
