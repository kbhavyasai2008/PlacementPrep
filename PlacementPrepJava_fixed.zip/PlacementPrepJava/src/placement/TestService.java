package placement;
import java.util.*;
public class TestService {
    public TestResult evaluate(String category,List<Question> questions,int[] answers){
        if(questions.size()!=answers.length)throw new IllegalArgumentException("Answer count mismatch");
        int correct=0;Map<String,TestResult.TopicScore> topics=new TreeMap<>();
        for(int i=0;i<questions.size();i++){
            Question q=questions.get(i);
            TestResult.TopicScore score=topics.computeIfAbsent(q.getTopic(),k->new TestResult.TopicScore());
            score.total++;
            if(answers[i]==q.getAnswer()){correct++;score.correct++;}
        }
        return new TestResult(category,correct,questions.size(),topics);
    }
}
