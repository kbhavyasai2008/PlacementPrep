package placement;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;
public class TestResult implements Serializable {
    private static final long serialVersionUID=1L;
    public static class TopicScore implements Serializable {
        private static final long serialVersionUID=1L;
        public int correct,total;
        public double percent(){return total==0?0:100.0*correct/total;}
    }
    private final String category, date;
    private final int correct,total;
    private final Map<String,TopicScore> topics;
    public TestResult(String category,int correct,int total,Map<String,TopicScore> topics){
        this.category=category;this.correct=correct;this.total=total;this.topics=new TreeMap<>(topics);
        this.date=LocalDateTime.now().toString().replace('T',' ').substring(0,16);
    }
    public String getCategory(){return category;}
    public String getDate(){return date;}
    public int getCorrect(){return correct;}
    public int getTotal(){return total;}
    public double getPercent(){return total==0?0:100.0*correct/total;}
    public Map<String,TopicScore> getTopics(){return Collections.unmodifiableMap(topics);}
}
