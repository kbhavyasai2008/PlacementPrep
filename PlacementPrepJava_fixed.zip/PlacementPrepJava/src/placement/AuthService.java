package placement;
import java.security.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class AuthService {
    private final Storage storage;
    private final SecureRandom random=new SecureRandom();
    public AuthService(Storage storage){this.storage=storage;}
    private String hash(String password,String salt){
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            byte[] bytes=digest.digest((salt+password).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(bytes);
        }catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }
    public String register(String username,String name,String password){
        username=username.trim().toLowerCase(Locale.ROOT);name=name.trim();
        if(!username.matches("[a-z0-9_]{3,24}"))return "Username must be 3-24 letters, numbers or underscores.";
        if(name.isEmpty())return "Please enter your name.";
        if(password.length()<6)return "Password must have at least 6 characters.";
        byte[] saltBytes=new byte[16];random.nextBytes(saltBytes);
        String salt=Base64.getEncoder().encodeToString(saltBytes);
        return storage.register(new User(username,name,salt,hash(password,salt)))?null:"Username already exists.";
    }
    public User login(String username,String password){
        User user=storage.findUser(username.trim().toLowerCase(Locale.ROOT));
        if(user==null)return null;
        byte[] a=user.getPasswordHash().getBytes(StandardCharsets.UTF_8);
        byte[] b=hash(password,user.getSalt()).getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(a,b)?user:null;
    }
}
