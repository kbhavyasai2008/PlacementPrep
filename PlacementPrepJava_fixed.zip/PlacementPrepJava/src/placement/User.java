package placement;
import java.io.Serializable;
public class User implements Serializable {
    private static final long serialVersionUID=1L;
    private final String username, name, salt, passwordHash;
    public User(String username,String name,String salt,String passwordHash) {
        this.username=username; this.name=name; this.salt=salt; this.passwordHash=passwordHash;
    }
    public String getUsername(){return username;}
    public String getName(){return name;}
    public String getSalt(){return salt;}
    public String getPasswordHash(){return passwordHash;}
}
