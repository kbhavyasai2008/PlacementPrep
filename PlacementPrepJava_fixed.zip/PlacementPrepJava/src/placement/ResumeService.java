package placement;
import java.util.*;
import java.util.regex.*;

/**
 * Compares a resume with a job description using a built-in skill vocabulary.
 *
 * Matching rules:
 *  - case-insensitive, whole-word matching (so "java" never matches inside "javascript")
 *  - spaces, hyphens and underscores in multi-word skills are flexible
 *    ("Spring Boot", "spring-boot", "SpringBoot", "Spring\nBoot" all match)
 *  - specific skills imply general ones on the resume side
 *    (MySQL => SQL, React => JavaScript, Spring Boot => Spring + Java, ...)
 */
public class ResumeService {

    /** One skill: display name, the patterns that detect it, and the skills it implies. */
    private static final class Skill {
        final String name;
        final String category;
        final List<Pattern> patterns=new ArrayList<>();
        final List<String> implies=new ArrayList<>();
        Skill(String name,String category){this.name=name;this.category=category;}
    }

    private static final Map<String,Skill> SKILLS=new LinkedHashMap<>();

    // ---------- vocabulary ----------
    static{
        // Programming languages
        add("Java","Languages","java","core java","advanced java","j2ee","java ee");
        add("Python","Languages","python","python3","python 3");
        add("C++","Languages","c++","cpp","c plus plus");
        add("C#","Languages","c#","csharp","c sharp");
        add("C","Languages","c language","c programming","programming in c","ansi c");
        // A bare capital "C" as its own word, but not C++, C#, Objective-C or C-DAC
        raw("C","(?<![\\p{L}\\p{N}\\-])C(?![\\p{L}\\p{N}+#\\-])",0);
        add("JavaScript","Languages","javascript","js","es6","ecmascript");
        add("TypeScript","Languages","typescript","ts");
        add("Kotlin","Languages","kotlin");
        add("Go","Languages","golang","go lang","go language");
        add("PHP","Languages","php");
        add("R","Languages","r programming","r language","r studio","rstudio");
        add("Swift","Languages","swift");
        add("Rust","Languages","rust");

        // Web / frameworks
        add("HTML","Web","html","html5");
        add("CSS","Web","css","css3","tailwind","tailwind css","bootstrap","sass","scss");
        add("React","Web","react","reactjs","react.js","react js","react native");
        add("Angular","Web","angular","angularjs","angular.js");
        add("Vue","Web","vue","vuejs","vue.js");
        add("Node.js","Web","nodejs","node.js","node js");
        add("Express","Web","expressjs","express.js");
        add("Spring","Web","spring framework","spring mvc","spring core","spring security","spring data");
        add("Spring Boot","Web","spring boot","springboot");
        add("Hibernate","Web","hibernate","jpa");
        add("Django","Web","django");
        add("Flask","Web","flask");
        add("REST API","Web","rest api","rest apis","restful","restful api","restful apis","restful services",
                "rest services","rest web services","rest endpoints","api development");
        add("JSP/Servlets","Web","jsp","servlet","servlets");

        // Databases
        add("SQL","Databases","sql","structured query language");
        add("MySQL","Databases","mysql");
        add("PostgreSQL","Databases","postgresql","postgres");
        add("Oracle DB","Databases","oracle","oracle db","pl/sql","plsql");
        add("MongoDB","Databases","mongodb","mongo db","mongo");
        add("DBMS","Databases","dbms","rdbms","database management","database management systems","database systems");

        // Tools / cloud / devops
        add("Git","Tools","git","version control");
        add("GitHub","Tools","github");
        add("GitLab","Tools","gitlab");
        add("Docker","Tools","docker","containerization","containerisation");
        add("Kubernetes","Tools","kubernetes","k8s");
        add("AWS","Tools","aws","amazon web services","ec2","aws lambda");
        add("Azure","Tools","azure","microsoft azure");
        add("GCP","Tools","gcp","google cloud","google cloud platform");
        add("Jenkins","Tools","jenkins");
        add("CI/CD","Tools","ci/cd","ci cd","cicd","continuous integration","continuous deployment","github actions");
        add("Linux","Tools","linux","ubuntu","unix","shell scripting","bash");
        add("Maven","Tools","maven");
        add("Postman","Tools","postman");
        add("JUnit","Tools","junit");
        add("Agile","Tools","agile","scrum");
        add("Excel","Tools","ms excel","microsoft excel","advanced excel","excel");
        add("Power BI","Tools","power bi","powerbi");
        add("Tableau","Tools","tableau");

        // CS fundamentals
        add("Data Structures","CS Fundamentals","data structures","data structure","dsa");
        add("Algorithms","CS Fundamentals","algorithms","algorithm","algorithm design","dsa");
        add("OOP","CS Fundamentals","oop","oops","object oriented programming","object oriented","object oriented design","ood");
        add("Operating Systems","CS Fundamentals","operating systems","operating system","os concepts");
        add("Computer Networks","CS Fundamentals","computer networks","computer networking","networking","cn","tcp/ip");
        add("System Design","CS Fundamentals","system design","low level design","high level design","lld","hld");
        add("Multithreading","CS Fundamentals","multithreading","multi threading","concurrency");

        // Data / AI
        add("Machine Learning","Data & AI","machine learning","ml");
        add("Deep Learning","Data & AI","deep learning","neural networks","cnn","rnn");
        add("Data Analysis","Data & AI","data analysis","data analytics","data analyst");
        add("Pandas","Data & AI","pandas");
        add("NumPy","Data & AI","numpy");
        add("TensorFlow","Data & AI","tensorflow");
        add("PyTorch","Data & AI","pytorch");
        add("NLP","Data & AI","nlp","natural language processing");

        // Soft skills
        add("Communication","Soft Skills","communication","communication skills","communicator","verbal and written");
        add("Problem Solving","Soft Skills","problem solving","problem solver","analytical skills","analytical thinking");
        add("Teamwork","Soft Skills","teamwork","team work","team player","collaboration","collaborative");
        add("Leadership","Soft Skills","leadership","team lead","led a team","leading a team");
        add("Time Management","Soft Skills","time management");

        // Implied skills (resume side): knowing the specific one shows the general one
        imply("MySQL","SQL");imply("PostgreSQL","SQL");imply("Oracle DB","SQL");imply("DBMS","SQL");
        imply("React","JavaScript");imply("Angular","JavaScript");imply("Vue","JavaScript");
        imply("Node.js","JavaScript");imply("Express","Node.js");imply("TypeScript","JavaScript");
        imply("Spring Boot","Spring");imply("Spring","Java");imply("Hibernate","Java");
        imply("JSP/Servlets","Java");imply("Maven","Java");imply("JUnit","Java");
        imply("Django","Python");imply("Flask","Python");imply("Pandas","Python");imply("NumPy","Python");
        imply("GitHub","Git");imply("GitLab","Git");
        imply("Kubernetes","Docker");
        imply("Deep Learning","Machine Learning");imply("TensorFlow","Deep Learning");imply("PyTorch","Deep Learning");
    }

    private static Skill skill(String name,String category){
        return SKILLS.computeIfAbsent(name,n->new Skill(n,category));
    }
    private static void add(String name,String category,String... aliases){
        Skill s=skill(name,category);
        for(String a:aliases)s.patterns.add(aliasPattern(a));
    }
    private static void raw(String name,String regex,int flags){
        skill(name,"Languages").patterns.add(Pattern.compile(regex,flags));
    }
    private static void imply(String from,String to){SKILLS.get(from).implies.add(to);}

    /** Builds a whole-word, case-insensitive pattern where spaces/hyphens are flexible. */
    private static Pattern aliasPattern(String alias){
        String[] parts=alias.toLowerCase(Locale.ROOT).trim().split("[\\s\\-_]+");
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<parts.length;i++){
            if(i>0)sb.append("[\\s\\-_]*");
            sb.append(Pattern.quote(parts[i]));
        }
        char first=alias.charAt(0),last=alias.charAt(alias.length()-1);
        String start=Character.isLetterOrDigit(first)?"(?<![\\p{L}\\p{N}])":"";
        // a word ending in a letter/digit must not continue as a longer word;
        // "c++" or "c#" may be followed by version digits (C++17)
        String end=Character.isLetterOrDigit(last)?"(?![\\p{L}\\p{N}+#])":"";
        return Pattern.compile(start+sb+end,Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
    }

    /** Cleans pasted / loaded text: BOM, non-breaking spaces, smart dashes. */
    static String normalize(String text){
        if(text==null)return "";
        return text.replace("﻿","")
                .replace(' ',' ').replace(' ',' ').replace(' ',' ')
                .replace('‐','-').replace('‑','-').replace('‒','-')
                .replace('–','-').replace('—','-');
    }

    /** Skills explicitly mentioned in the text (no implications). */
    public Set<String> extract(String text){
        String t=normalize(text);
        Set<String> result=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for(Skill s:SKILLS.values()){
            for(Pattern p:s.patterns)if(p.matcher(t).find()){result.add(s.name);break;}
        }
        return result;
    }

    /** Adds every skill implied by the found skills (transitively). */
    private Set<String> withImplied(Set<String> skills){
        Set<String> all=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);all.addAll(skills);
        Deque<String> queue=new ArrayDeque<>(skills);
        while(!queue.isEmpty()){
            Skill s=SKILLS.get(queue.poll());
            if(s==null)continue;
            for(String i:s.implies)if(all.add(i))queue.add(i);
        }
        return all;
    }

    public static String categoryOf(String skill){
        Skill s=SKILLS.get(skill);return s==null?"Other":s.category;
    }

    public static class Comparison {
        /** Skills required by the job description. */
        public final Set<String> required;
        /** Required skills present on the resume. */
        public final Set<String> matched;
        /** Required skills not found on the resume. */
        public final Set<String> missing;
        /** All skills detected on the resume (including implied ones). */
        public final Set<String> resumeSkills;
        /** Resume skills the job description did not ask for. */
        public final Set<String> extra;
        public Comparison(Set<String> required,Set<String> matched,Set<String> missing,
                          Set<String> resumeSkills,Set<String> extra){
            this.required=required;this.matched=matched;this.missing=missing;
            this.resumeSkills=resumeSkills;this.extra=extra;
        }
        public Comparison(Set<String> required,Set<String> matched,Set<String> missing){
            this(required,matched,missing,new TreeSet<>(matched),new TreeSet<>());
        }
        public double matchPercent(){return required.isEmpty()?0:100.0*matched.size()/required.size();}
        public String verdict(){
            if(required.isEmpty())return "No recognisable skills in the job description";
            double p=matchPercent();
            if(p>=80)return "Strong match";
            if(p>=60)return "Good match";
            if(p>=40)return "Partial match";
            return "Weak match";
        }
    }

    public Comparison compare(String resume,String job){
        Set<String> required=extract(job);
        Set<String> found=withImplied(extract(resume));
        Set<String> matched=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Set<String> missing=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for(String r:required)(found.contains(r)?matched:missing).add(r);
        Set<String> extra=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for(String f:found)if(!required.contains(f))extra.add(f);
        return new Comparison(required,matched,missing,found,extra);
    }

    /** Human-readable report used by the GUI (and by the command-line demo). */
    public String report(Comparison c){
        StringBuilder sb=new StringBuilder();
        if(c.required.isEmpty()){
            sb.append("No known skill keywords were found in the job description.\n");
            sb.append("Tip: paste the 'Requirements' / 'Skills' section of the job posting.\n\n");
            sb.append("Skills detected on your resume (").append(c.resumeSkills.size()).append("): ")
              .append(c.resumeSkills.isEmpty()?"none":String.join(", ",c.resumeSkills)).append('\n');
            return sb.toString();
        }
        sb.append(String.format(Locale.US,"KEYWORD MATCH: %.0f%%  (%d of %d required skills)  -  %s%n",
                c.matchPercent(),c.matched.size(),c.required.size(),c.verdict()));
        int filled=(int)Math.round(c.matchPercent()/5);
        sb.append('[');for(int i=0;i<20;i++)sb.append(i<filled?'#':'-');sb.append("]\n\n");

        sb.append("MATCHED SKILLS (").append(c.matched.size()).append(")\n");
        if(c.matched.isEmpty())sb.append("  none\n");
        for(String s:c.matched)sb.append("  [+] ").append(s).append('\n');

        sb.append("\nMISSING SKILLS (").append(c.missing.size()).append(")\n");
        if(c.missing.isEmpty())sb.append("  none - your resume covers every skill the job lists!\n");
        for(String s:c.missing)sb.append("  [-] ").append(s).append("   (").append(categoryOf(s)).append(")\n");

        if(!c.extra.isEmpty()){
            sb.append("\nOTHER SKILLS ON YOUR RESUME (not asked for in this job)\n  ")
              .append(String.join(", ",c.extra)).append('\n');
        }
        if(!c.missing.isEmpty()){
            sb.append("\nSUGGESTIONS\n");
            sb.append("  - If you already know a missing skill, add it in the exact words the job uses.\n");
            sb.append("  - Mention it inside a project or internship bullet, not only in the skills list.\n");
            sb.append("  - Focus first on: ").append(String.join(", ",
                    new ArrayList<>(c.missing).subList(0,Math.min(3,c.missing.size())))).append('\n');
        }
        sb.append("\nNote: this is keyword matching, not a hiring decision or an official ATS score.\n");
        return sb.toString();
    }
}
