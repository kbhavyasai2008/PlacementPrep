package placement;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
public class Main extends JFrame {
    private final Storage storage=new Storage();
    private final AuthService auth=new AuthService(storage);
    private final TestService tester=new TestService();
    private final ResumeService resumeService=new ResumeService();
    private User current;
    private final JPanel content=new JPanel(new BorderLayout(12,12));
    private final Color navy=new Color(25,39,67), blue=new Color(49,103,190);
    private final Color muted=new Color(103,117,140), green=new Color(28,135,111);
    public Main(){
        super("Placement Prep | Java OOP");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1080,760);setMinimumSize(new Dimension(850,620));
        setLocationRelativeTo(null);
        content.setBorder(new EmptyBorder(20,24,20,24));
        content.setBackground(new Color(247,249,253));
        setContentPane(content);
        showAuth(false);
    }
    private JLabel heading(String title){
        JLabel l=new JLabel(title);l.setFont(new Font("SansSerif",Font.BOLD,25));l.setForeground(navy);return l;
    }
    private JButton button(String text,Runnable action){
        JButton b=new JButton(text);b.setBackground(blue);b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif",Font.BOLD,13));b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(9,14,9,14));b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e->action.run());return b;
    }
    private void display(JComponent center,String title,JComponent topRight){
        content.removeAll();
        JPanel header=new JPanel(new BorderLayout());header.setOpaque(false);
        header.add(heading(title),BorderLayout.WEST);
        if(topRight!=null)header.add(topRight,BorderLayout.EAST);
        content.add(header,BorderLayout.NORTH);content.add(center,BorderLayout.CENTER);
        content.revalidate();content.repaint();
    }
    private JPanel panel(){
        JPanel p=new JPanel();p.setBackground(Color.WHITE);p.setBorder(new CompoundBorder(
            new LineBorder(new Color(225,231,241)),new EmptyBorder(18,18,18,18)));return p;
    }
    private void alert(String message){JOptionPane.showMessageDialog(this,message);}
    private void showAuth(boolean register){
        JPanel outer=panel();outer.setLayout(new GridBagLayout());
        JPanel fields=new JPanel(new GridLayout(0,1,7,7));fields.setOpaque(false);
        JTextField username=new JTextField(25),name=new JTextField(25);
        JPasswordField password=new JPasswordField(25);
        if(register){fields.add(new JLabel("Full name"));fields.add(name);}
        fields.add(new JLabel("Username"));fields.add(username);
        fields.add(new JLabel("Password"));fields.add(password);
        JButton submit=button(register?"Create account":"Log in",()->{
            try{
                String user=username.getText(),pass=new String(password.getPassword());
                if(register){
                    String error=auth.register(user,name.getText(),pass);
                    if(error!=null)alert(error);else{alert("Account created. Please log in.");showAuth(false);}
                }else{
                    current=auth.login(user,pass);
                    if(current==null)alert("Incorrect username or password.");
                    else showDashboard();
                }
            }catch(Exception ex){error(ex);}
        });
        JButton switcher=new JButton(register?"Already registered? Log in":"New student? Register");
        switcher.addActionListener(e->showAuth(!register));
        fields.add(submit);fields.add(switcher);outer.add(fields);
        display(outer,register?"Student Registration":"Student Login",null);
    }
    private JPanel nav(){
        JPanel nav=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));nav.setOpaque(false);
        nav.add(button("Dashboard",this::showDashboard));
        nav.add(button("Mock Test",this::showTestSetup));
        nav.add(button("History",this::showHistory));
        nav.add(button("Resume Checker",this::showResume));
        nav.add(button("Logout",()->{current=null;showAuth(false);}));
        return nav;
    }
    private void showDashboard(){
        JPanel p=panel();p.setLayout(new BorderLayout(16,16));
        List<TestResult> results=storage.getResults(current.getUsername());
        JPanel overview=new JPanel(new BorderLayout(4,4));overview.setOpaque(false);
        JLabel welcome=new JLabel("Welcome back, "+current.getName());
        welcome.setFont(new Font("SansSerif",Font.BOLD,24));welcome.setForeground(navy);
        JLabel subtitle=new JLabel("Your placement-prep progress, at a glance.");
        subtitle.setForeground(muted);
        overview.add(welcome,BorderLayout.NORTH);overview.add(subtitle,BorderLayout.SOUTH);
        p.add(overview,BorderLayout.NORTH);
        double average=0;
        if(!results.isEmpty()){
            for(TestResult r:results)average+=r.getPercent();
            average/=results.size();
        }
        JPanel center=new JPanel(new BorderLayout(14,14));center.setOpaque(false);
        JPanel stats=new JPanel(new GridLayout(1,3,12,0));stats.setOpaque(false);
        stats.add(statCard("TESTS COMPLETED",String.valueOf(results.size()),"Keep your momentum going"));
        stats.add(statCard("AVERAGE SCORE",String.format(Locale.US,"%.1f%%",average),"Across all completed tests"));
        TestResult latest=results.isEmpty()?null:results.get(results.size()-1);
        stats.add(statCard("LATEST RESULT",latest==null?"—":String.format(Locale.US,"%.0f%%",latest.getPercent()),
            latest==null?"Take your first mock test":latest.getCategory()+" · "+latest.getDate()));
        center.add(stats,BorderLayout.NORTH);
        JPanel lower=new JPanel(new GridLayout(1,2,12,0));lower.setOpaque(false);
        JPanel strengths=panel();strengths.setLayout(new BorderLayout(8,8));
        strengths.add(sectionTitle("Your strengths"),BorderLayout.NORTH);
        strengths.add(strengthsContent(results),BorderLayout.CENTER);
        JPanel start=panel();start.setLayout(new BorderLayout(10,10));
        start.add(sectionTitle("Ready to practice?"),BorderLayout.NORTH);
        JLabel prompt=new JLabel("<html>Choose a subject, build consistency,<br>and track your progress over time.</html>");
        prompt.setFont(new Font("SansSerif",Font.PLAIN,15));prompt.setForeground(muted);
        start.add(prompt,BorderLayout.CENTER);
        start.add(button("Start a mock test",this::showTestSetup),BorderLayout.SOUTH);
        lower.add(strengths);lower.add(start);center.add(lower,BorderLayout.CENTER);
        p.add(center,BorderLayout.CENTER);
        display(p,"Student Dashboard",nav());
    }
    private JPanel statCard(String label,String value,String detail){
        JPanel card=panel();card.setLayout(new BorderLayout(5,7));
        JLabel title=new JLabel(label);title.setFont(new Font("SansSerif",Font.BOLD,11));title.setForeground(muted);
        JLabel number=new JLabel(value);number.setFont(new Font("SansSerif",Font.BOLD,26));number.setForeground(navy);
        JLabel note=new JLabel(detail);note.setFont(new Font("SansSerif",Font.PLAIN,12));note.setForeground(muted);
        card.add(title,BorderLayout.NORTH);card.add(number,BorderLayout.CENTER);card.add(note,BorderLayout.SOUTH);
        return card;
    }
    private JLabel sectionTitle(String title){
        JLabel label=new JLabel(title);label.setFont(new Font("SansSerif",Font.BOLD,18));label.setForeground(navy);return label;
    }
    private JComponent strengthsContent(List<TestResult> results){
        Map<String,int[]> totals=new HashMap<>();
        for(TestResult result:results)for(Map.Entry<String,TestResult.TopicScore> entry:result.getTopics().entrySet()){
            int[] score=totals.computeIfAbsent(entry.getKey(),key->new int[2]);
            score[0]+=entry.getValue().correct;score[1]+=entry.getValue().total;
        }
        if(totals.isEmpty()){
            JLabel empty=new JLabel("<html>Complete a mock test to discover<br>your strongest subjects.</html>");
            empty.setForeground(muted);return empty;
        }
        List<Map.Entry<String,int[]>> ranked=new ArrayList<>(totals.entrySet());
        ranked.sort((a,b)->Double.compare((double)b.getValue()[0]/b.getValue()[1],
            (double)a.getValue()[0]/a.getValue()[1]));
        JPanel list=new JPanel(new GridLayout(0,1,8,8));list.setOpaque(false);
        for(int i=0;i<Math.min(3,ranked.size());i++){
            Map.Entry<String,int[]> item=ranked.get(i);int[] score=item.getValue();
            JLabel strength=new JLabel(String.format(Locale.US,"  %s   ·   %d%%  (%d/%d)",
                item.getKey(),100*score[0]/score[1],score[0],score[1]));
            strength.setFont(new Font("SansSerif",Font.BOLD,14));strength.setForeground(green);
            list.add(strength);
        }
        return list;
    }
    private void showTestSetup(){
        JPanel p=panel();p.setLayout(new BorderLayout(14,14));
        JPanel form=new JPanel(new GridBagLayout());form.setOpaque(false);
        GridBagConstraints gbc=new GridBagConstraints();gbc.gridx=0;gbc.gridy=0;
        gbc.weightx=1;gbc.fill=GridBagConstraints.HORIZONTAL;gbc.anchor=GridBagConstraints.WEST;
        gbc.insets=new Insets(5,2,5,2);
        JComboBox<String> category=new JComboBox<>(new String[]{"Mixed","Aptitude","Technical"});
        JSpinner count=new JSpinner(new SpinnerNumberModel(10,1,20,1));
        JPanel subjects=new JPanel(new GridLayout(0,2,8,8));subjects.setOpaque(false);
        JCheckBox all=new JCheckBox("Select all subjects",true);all.setOpaque(false);
        List<JCheckBox> choices=new ArrayList<>();
        Runnable refreshSubjects=()->{
            String selected=(String)category.getSelectedItem();
            subjects.removeAll();choices.clear();
            for(String topic:QuestionBank.topics(selected)){
                JCheckBox choice=new JCheckBox(topic,true);choice.setOpaque(false);
                choice.addActionListener(e->{
                    boolean every=choices.stream().allMatch(JCheckBox::isSelected);
                    all.setSelected(every);updateQuestionLimit(count,selected,selectedTopics(choices));
                });
                choices.add(choice);subjects.add(choice);
            }
            all.setSelected(true);updateQuestionLimit(count,selected,selectedTopics(choices));
            subjects.revalidate();subjects.repaint();
        };
        all.addActionListener(e->{
            for(JCheckBox choice:choices)choice.setSelected(all.isSelected());
            updateQuestionLimit(count,(String)category.getSelectedItem(),selectedTopics(choices));
        });
        category.addActionListener(e->refreshSubjects.run());
        JLabel subjectLabel=sectionTitle("Choose subjects");
        JScrollPane subjectScroll=new JScrollPane(subjects);subjectScroll.setBorder(new LineBorder(new Color(225,231,241)));
        subjectScroll.setPreferredSize(new Dimension(420,160));
        addFormRow(form,gbc,"Test category",category);
        addFormRow(form,gbc,"Subjects",subjectLabel);
        addFormRow(form,gbc,"",all);
        addFormRow(form,gbc,"",subjectScroll);
        addFormRow(form,gbc,"Number of questions",count);
        refreshSubjects.run();
        p.add(form,BorderLayout.NORTH);
        p.add(button("Start test",()->{
            String c=(String)category.getSelectedItem();
            List<String> selected=selectedTopics(choices);
            int available=QuestionBank.count(c,selected);
            if(available==0){alert("Select at least one subject.");return;}
            List<Question> questions=QuestionBank.select(c,selected,(Integer)count.getValue());
            showQuestion(questions,c,0,new int[questions.size()]);
        }),BorderLayout.SOUTH);
        display(p,"Start Mock Test",nav());
    }
    private void addFormRow(JPanel form,GridBagConstraints gbc,String label,JComponent component){
        gbc.gridx=0;gbc.weightx=0;form.add(new JLabel(label),gbc);
        gbc.gridx=1;gbc.weightx=1;form.add(component,gbc);gbc.gridy++;
    }
    private List<String> selectedTopics(List<JCheckBox> choices){
        List<String> selected=new ArrayList<>();
        for(JCheckBox choice:choices)if(choice.isSelected())selected.add(choice.getText());
        return selected;
    }
    private void updateQuestionLimit(JSpinner count,String category,List<String> topics){
        int available=QuestionBank.count(category,topics);
        SpinnerNumberModel model=(SpinnerNumberModel)count.getModel();
        model.setMaximum(Math.max(1,available));
        model.setValue(Math.max(1,Math.min((Integer)model.getValue(),Math.max(1,available))));
    }
    private void showQuestion(List<Question> questions,String category,int index,int[] answers){
        if(index>=questions.size()){
            int[] chosen=Arrays.copyOf(answers,questions.size());
            TestResult result=tester.evaluate(category,questions,chosen);
            storage.saveResult(current.getUsername(),result);
            showResult(result);return;
        }
        Question q=questions.get(index);
        JPanel p=panel();p.setLayout(new BorderLayout(10,15));
        JPanel body=new JPanel(new GridLayout(0,1,12,12));body.setOpaque(false);
        body.add(new JLabel("Question "+(index+1)+" of "+questions.size()+" | "+q.getCategory()+" / "+q.getTopic()));
        JTextArea prompt=new JTextArea(q.getPrompt());prompt.setEditable(false);prompt.setLineWrap(true);
        prompt.setWrapStyleWord(true);prompt.setFont(new Font("SansSerif",Font.BOLD,17));prompt.setOpaque(false);
        body.add(prompt);
        ButtonGroup group=new ButtonGroup();List<JRadioButton> radios=new ArrayList<>();
        String[] options=q.getOptions();
        for(int i=0;i<options.length;i++){
            JRadioButton rb=new JRadioButton((char)('A'+i)+". "+options[i]);rb.setOpaque(false);
            group.add(rb);radios.add(rb);body.add(rb);
        }
        p.add(body,BorderLayout.NORTH);
        p.add(button(index==questions.size()-1?"Submit Test":"Next Question",()->{
            int selected=-1;for(int i=0;i<radios.size();i++)if(radios.get(i).isSelected())selected=i;
            if(selected<0){alert("Please select an answer.");return;}
            answers[index]=selected;showQuestion(questions,category,index+1,answers);
        }),BorderLayout.SOUTH);
        display(p,"Mock Test",null);
    }
    private void showResult(TestResult result){
        JPanel p=panel();p.setLayout(new BorderLayout(10,10));
        JTextArea report=new JTextArea(report(result));report.setEditable(false);
        report.setFont(new Font("Monospaced",Font.PLAIN,15));report.setBackground(Color.WHITE);
        p.add(new JScrollPane(report),BorderLayout.CENTER);
        p.add(button("Return to Dashboard",this::showDashboard),BorderLayout.SOUTH);
        display(p,"Test Result and Topic Analysis",null);
    }
    private String report(TestResult r){
        StringBuilder sb=new StringBuilder();
        sb.append("Date: ").append(r.getDate()).append("\nCategory: ").append(r.getCategory());
        sb.append(String.format(Locale.US,"\nScore: %d / %d (%.1f%%)\n\n",r.getCorrect(),r.getTotal(),r.getPercent()));
        sb.append("TOPIC-WISE PERFORMANCE\n");
        for(Map.Entry<String,TestResult.TopicScore> e:r.getTopics().entrySet()){
            TestResult.TopicScore s=e.getValue();
            sb.append(String.format(Locale.US,"%-22s %d/%d (%.0f%%)%s\n",
                e.getKey(),s.correct,s.total,s.percent(),s.percent()<60?"  <-- Needs practice":""));
        }
        sb.append("\nTopics below 60% are highlighted for improvement.\n");
        return sb.toString();
    }
    private void showHistory(){
        List<TestResult> results=storage.getResults(current.getUsername());
        JPanel p=panel();p.setLayout(new BorderLayout(10,10));
        DefaultListModel<String> model=new DefaultListModel<>();
        for(int i=results.size()-1;i>=0;i--){
            TestResult r=results.get(i);
            model.addElement(String.format(Locale.US,"%s | %s | %d/%d | %.1f%%",
                r.getDate(),r.getCategory(),r.getCorrect(),r.getTotal(),r.getPercent()));
        }
        JList<String> list=new JList<>(model);list.setFont(new Font("Monospaced",Font.PLAIN,13));
        p.add(new JScrollPane(list),BorderLayout.CENTER);
        p.add(button("View Selected Analysis",()->{
            int i=list.getSelectedIndex();
            if(i<0){alert("Select a test first.");return;}
            showResult(results.get(results.size()-1-i));
        }),BorderLayout.SOUTH);
        display(p,"Previous Test Results",nav());
    }
    private void showResume(){
        JPanel p=panel();p.setLayout(new BorderLayout(10,10));
        JTextArea resume=new JTextArea(10,40),job=new JTextArea(10,40),output=new JTextArea(12,40);
        for(JTextArea a:new JTextArea[]{resume,job,output}){a.setLineWrap(true);a.setWrapStyleWord(true);}
        output.setEditable(false);output.setFont(new Font("Monospaced",Font.PLAIN,13));
        output.setText("Paste your resume on the left and the job description on the right,\n"+
            "then click Compare Skills.");
        JPanel inputs=new JPanel(new GridLayout(1,2,12,0));inputs.setOpaque(false);
        inputs.add(textInput("Resume text (paste or load .txt)",resume));
        inputs.add(textInput("Job description (paste or load .txt)",job));
        p.add(inputs,BorderLayout.NORTH);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));actions.setOpaque(false);
        actions.add(button("Compare Skills",()->{
            if(resume.getText().trim().isEmpty()||job.getText().trim().isEmpty()){
                alert("Enter both resume text and a job description.");return;
            }
            ResumeService.Comparison c=resumeService.compare(resume.getText(),job.getText());
            output.setText(resumeService.report(c));
            output.setCaretPosition(0);
        }));
        actions.add(button("Clear",()->{resume.setText("");job.setText("");output.setText("");}));
        JPanel bottom=new JPanel(new BorderLayout(8,8));bottom.setOpaque(false);
        bottom.add(actions,BorderLayout.NORTH);
        bottom.add(new JScrollPane(output),BorderLayout.CENTER);
        p.add(bottom,BorderLayout.CENTER);
        display(p,"Resume Keyword Checker",nav());
    }
    private JPanel textInput(String label,JTextArea area){
        JPanel box=new JPanel(new BorderLayout(5,5));box.setOpaque(false);
        JPanel top=new JPanel(new BorderLayout());top.setOpaque(false);
        top.add(new JLabel(label),BorderLayout.CENTER);
        top.add(button("Load .txt",()->loadText(area)),BorderLayout.EAST);
        box.add(top,BorderLayout.NORTH);box.add(new JScrollPane(area),BorderLayout.CENTER);
        return box;
    }
    private void loadText(JTextArea target){
        JFileChooser chooser=new JFileChooser();
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Text files (*.txt)","txt"));
        if(chooser.showOpenDialog(this)!=JFileChooser.APPROVE_OPTION)return;
        Path path=chooser.getSelectedFile().toPath();
        if(!path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".txt")){
            alert("Please choose a plain-text (.txt) file.\nFor PDF/Word resumes, open the file, copy all text and paste it here.");
            return;
        }
        try{
            target.setText(readText(Files.readAllBytes(path)));
            target.setCaretPosition(0);
        }catch(Exception e){error(e);}
    }
    /** Reads UTF-8 (with or without BOM), UTF-16 (Notepad "Unicode") or ANSI/Windows-1252 text. */
    static String readText(byte[] bytes){
        if(bytes.length>=2&&(bytes[0]==(byte)0xFF&&bytes[1]==(byte)0xFE||bytes[0]==(byte)0xFE&&bytes[1]==(byte)0xFF))
            return new String(bytes,StandardCharsets.UTF_16);
        try{
            String s=StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(bytes)).toString();
            return s.startsWith("\uFEFF")?s.substring(1):s;
        }catch(java.nio.charset.CharacterCodingException e){
            return new String(bytes,java.nio.charset.Charset.forName("windows-1252"));
        }
    }
    private void error(Exception e){JOptionPane.showMessageDialog(this,e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
    public static void main(String[] args){
        SwingUtilities.invokeLater(()->{try{new Main().setVisible(true);}
        catch(Exception e){JOptionPane.showMessageDialog(null,e.toString(),"Startup error",JOptionPane.ERROR_MESSAGE);}});
    }
}
