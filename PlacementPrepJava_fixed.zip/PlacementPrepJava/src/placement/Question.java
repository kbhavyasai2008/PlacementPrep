package placement;
import java.util.*;
public class Question {
    private final String category,topic,prompt;
    private final String[] options;
    private final int answer;
    public Question(String category,String topic,String prompt,int answer,String... options) {
        this.category=category;this.topic=topic;this.prompt=prompt;this.answer=answer;this.options=options.clone();
        if(options.length!=4 || answer<0 || answer>3)throw new IllegalArgumentException("Invalid question");
    }
    public String getCategory(){return category;}
    public String getTopic(){return topic;}
    public String getPrompt(){return prompt;}
    public String[] getOptions(){return options.clone();}
    public int getAnswer(){return answer;}
}
