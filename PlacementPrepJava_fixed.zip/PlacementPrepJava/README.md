# Placement Preparation & Mock Test Platform

A complete offline Java Swing desktop application demonstrating Object-Oriented Programming.

## Features
- Student registration and login (salted SHA-256 password hashes)
- Aptitude, Technical and Mixed multiple-choice mock tests (20 built-in questions)
- Select individual subjects or combine them in a custom mock test
- Automatic marking and result generation
- Topic-wise correct/total statistics and weak-topic flagging (below 60%)
- Dashboard progress cards and a strengths section based on test history
- Persistent test history per student
- Resume-to-job-description keyword matching with matched, missing and extra skills
- ~90 recognised skills (languages, frameworks, databases, tools, CS fundamentals, soft skills) with aliases
- Smart matching: flexible spacing/hyphens (`Spring-Boot`, `SpringBoot`), related skills (MySQL counts as SQL, React as JavaScript, GitHub as Git)
- Match verdict, progress bar and improvement suggestions
- Import `.txt` resumes or job descriptions (UTF-8, UTF-16 or Windows ANSI) or paste text

## Requirements
- JDK 11 or newer (JDK 17 or 21 recommended)
- VS Code with **Extension Pack for Java** (optional; command-line run also works)
- No Maven, Gradle, database or third-party dependencies

## Run in VS Code
1. Extract this ZIP.
2. Open the **PlacementPrepJava** folder in VS Code (File > Open Folder).
3. Install **Extension Pack for Java** if prompted.
4. Open `src/placement/Main.java`.
5. Click **Run** above the `main` method. The desktop window opens.

## Run from terminal
From the project root:

**Windows PowerShell**
```powershell
mkdir out
javac -encoding UTF-8 -d out src/placement/*.java
java -cp out placement.Main
```

**macOS / Linux**
```bash
mkdir -p out
javac -encoding UTF-8 -d out src/placement/*.java
java -cp out placement.Main
```

Or use `run.bat` (Windows) / `bash run.sh` (macOS/Linux).

## Try it
1. Register a student username, name and password.
2. Log in and select Mock Test.
3. Choose Aptitude, Technical or Mixed, select subjects and a question count, then answer questions.
4. Submit to see score and topic-wise breakdown.
5. View saved tests from History.
6. Paste a resume and job description into Resume Checker, then click Compare Skills.

Example resume: `Java, SQL, Git, OOP, HTML`
Example job description: `Looking for Java, SQL, Spring Boot, Git, Docker, and communication skills.`

## OOP concepts demonstrated
- **Encapsulation**: private fields with getters in `User`, `Question`, `TestResult`.
- **Abstraction / separation of responsibilities**: `AuthService`, `TestService`, `ResumeService`, `Storage`.
- **Composition**: `Main` owns service objects; `TestResult` owns topic scores.
- **Collections and generics**: `List<Question>`, `Map<String,TopicScore>`.
- **Exception handling**: file IO and login / startup error handling.
- **Java Swing event-driven GUI**: buttons and listeners.

This version focuses on clean class design rather than artificially adding inheritance. If your instructor specifically requires inheritance and interfaces, they can be added meaningfully.

## Data storage and limitations
- Saved users and results are stored under `~/.placement-prep-java/` on your computer.
- Uses local Java serialization for coursework simplicity; do not use it with untrusted files.
- Passwords are salted and hashed, but a production system should use a slow password KDF such as Argon2 or bcrypt and a proper database.
- Resume checker supports **pasted text and UTF-8 .txt files**, not PDF/DOCX extraction.
- Keyword matching uses a built-in skill vocabulary with aliases and implied skills; it is not semantic AI analysis. Add new skills in the `static` block of `ResumeService.java`.
- This is an offline educational prototype, not a production-grade placement platform.
